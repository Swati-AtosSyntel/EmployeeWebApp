﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EmployeeWebApp.Models
{
    public class Student
    {
        [RegularExpression("S[0-9]/{3}")]
        public int sid { get; set; }
        [ScaffoldColumn(false)]
        public string sname { get; set; }
    }
}