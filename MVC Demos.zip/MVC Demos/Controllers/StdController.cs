﻿using EmployeeWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeWebApp.Controllers
{
    public class StdController : Controller
    {
       public static List<Student> students = new List<Student>();
            
        // GET: Std
        public ActionResult Index()
        {
           
            return View(students);
        }

        // GET: Std/Details/5
        public ActionResult Details(int? id)
        {
            return View();
        }

        // GET: Std/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Std/Create
        [HttpPost]
        //public ActionResult Create(FormCollection forms)
        //{
        //    try
        //    {
        //        Student s = new Student();
        //        s.sid = Convert.ToInt32(forms["sid"]);
        //        s.sname = forms["sname"];
        //        // TODO: Add insert logic here
        //        students.Add(s);
        //        return RedirectToAction("Index",students);
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
        //public ActionResult Create(Student s)
        //{
        //    try
        //    {
                
        //        students.Add(s);
        //        return RedirectToAction("Index", students);
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
        public ActionResult Create(int id,string name)
        {
            try
            {
                Student s = new Student();
                s.sid = id;
                s.sname = name;
                students.Add(s);
                return RedirectToAction("Index", students);
            }
            catch
            {
                return View();
            }
        }

        // GET: Std/Edit/5
        public ActionResult Edit(int? id)
        {
            return View();
        }

        // POST: Std/Edit/5
        [HttpPost]
        public ActionResult Edit(int? id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Std/Delete/5
        public ActionResult Delete(int? id)
        {
            return View();
        }

        // POST: Std/Delete/5
        [HttpPost]
        public ActionResult Delete(int? id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
