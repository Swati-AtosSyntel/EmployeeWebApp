﻿using EmployeeWebApp.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace EmployeeWebApp.Controllers
{
    public class LINQController : Controller
    {
        List<employee> employees = new List<employee>()
        {
            new employee(){empid=234,ename="Swati",emailid="Swati.Bhirud@atos.net",location="Pune"},
            new employee(){empid=235,ename="Nishant",emailid="Nishant.Bhirud@atos.net",location="Pune"},
            new employee(){empid=236,ename="Mohit",emailid="Mohit.N@atos.net",location="Mumbai"},
            new employee(){empid=237,ename="Vrushali",emailid="Vrushali.P@atos.net",location="Chennai"},
            new employee(){empid=238,ename="Shivani",emailid="Shivani.V@atos.net",location="Chennai"},
        };
        // GET: LINQ
        public ActionResult Index()
        {

            return View(employees);
        }
        public ActionResult EnameList()
        {
            //var names = employees.Select(e => e.ename);
            var names = from e in employees
                        select e.ename;
            return PartialView(names);
        }
        public ActionResult LocationWiseEmpList()
        {
            //var emplist = employees.Where(e => e.location == "Chennai")
            //    .Select(emp => emp.ename);
            //ViewBag.list = emplist;
            return View();
        }
    }
}