﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeWebApp.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            string text = "This is MVC Application!!!";
            ViewData["msg"] = text;
            ViewBag.message = text;
            TempData["message1"] = text;
            return RedirectToAction("Index1");
        }
        public string ShowMessage()
        {
            return "Welcome to MVC Application";
        }
        public ActionResult Index1()
        {
            if (TempData.ContainsKey("message1"))
                TempData.Keep();
                return View();
        }
        public string Index2()
        {
            string textmessage="";
            if (TempData.ContainsKey("message1"))
                textmessage = TempData["message1"].ToString();

            return textmessage;
        }
    }
}