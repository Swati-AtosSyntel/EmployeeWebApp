﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication1.Models
{
    public class CountryInfo
    {
        public string country { get; set; }
        public List<string> cities { get; set; }
    }
}