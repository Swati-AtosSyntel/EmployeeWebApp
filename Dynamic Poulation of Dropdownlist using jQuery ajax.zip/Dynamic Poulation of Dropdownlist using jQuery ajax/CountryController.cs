﻿using MvcApplication1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication1.Controllers
{
    public class CountryController : Controller
    {
        // GET: Country
        List<CountryInfo> countries = new List<CountryInfo>()
            {
                new CountryInfo(){country="India",cities=new List<string>(){"Mumbai","Banglore"} },
                new CountryInfo(){country="USA",cities=new List<string>(){"Cidney","Newyork"} },
                new CountryInfo(){country="UK",cities=new List<string>(){"London","Manchestor"} }
            };
        public ActionResult Index()
        {
            
            var countrylist = countries.Select(c => c.country);
            ViewBag.countryList = countrylist;
            return View();
        }
        public JsonResult getCities(string countryName)
        {
            var cities = countries.Where(c => c.country == countryName).Select(c => c.cities);
            return Json(cities, JsonRequestBehavior.AllowGet);
        }
    }
}